# CLEAR-ALL
**Clean streets. Connected citizens.** — BinBuddy: CleanStreet Challenge demo.

## Run locally
1. Install Node.js 20 or newer.
2. Unzip this project and open the folder in VS Code.
3. Open a terminal in the project folder and run:
   ```bash
   npm install
   npm run dev
   ```
4. Open the local URL printed by Vite (usually `http://localhost:5173`).

## Demo walkthrough
1. Open **Segregation Guide** and search `broken tube light`. It returns the red Hazardous stream with a safe-handling tip.
2. Open **Report an issue**. The default example is the overflowing dumpster outside Colony Park. Submit it; the new ticket appears immediately on the Ward Board.
3. Upvote the new ticket. A second upvote from the same browser/device is blocked.
4. Open **Live Tracking** for the fleet simulation and arrival countdown.
5. Switch the navbar role to **Supervisor**, then open **Sanitation**. Assign a worker and change the ticket status to Cleaned.
6. Open **Analytics** and **Eco Rewards** to see the updated status and points.

## Included
- Responsive white/blue CLEAR-ALL interface, optional navy dark mode, cursor-following card spotlight, reduced-motion support.
- Resident, Worker and Supervisor role switcher; Home, Schedule, Live Tracking, Report, Ward Board, Segregation Guide, Eco Rewards, Sanitation, Analytics, E-Waste Drive, Notifications and Settings.
- 50 waste lookup entries, seeded ward reports (3 Reported, 3 Assigned, 2 Cleaned), 5 fleet vehicles, 3 wards and 3 workers.
- Multi-step report flow, local duplicate hint, photo preview, device-scoped upvote prevention, ticket details, CSV and calendar export.
- Local demo data persisted in `localStorage`, no account or API key required.
- Supabase SQL schema/migration in `supabase/migrations/`.

## Architecture notes
- React + Vite + TypeScript; CSS is deliberately custom and lightweight so the design remains easy to tune.
- `src/services.ts` centralises seed data, local persistence, IDs and utility functions.
- The browser-local adapter is the default resilient demo mode. The SQL migration provides the Supabase data model. To connect a hosted Supabase project, add environment configuration and implement the service adapter in one place before enabling remote writes.
- The fleet map is an illustrative local simulation surface, not actual GPS. Real GPS requires a trusted worker mobile app/device and consented location updates.
- The SQL migration is a hackathon/demo starting point. Before production, replace permissive demo RLS policies with authenticated role-based policies, validate uploads server-side, add rate limiting, and protect personal/location data.

## Build
`npm run build`
